<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Drpds_facelifting extends Model
{
    use HasFactory;

    protected $table = 'drpds_facelifting';
    protected $primaryKey = 'id';
    public $timestamps = true;
}
